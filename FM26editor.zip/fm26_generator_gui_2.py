#!/usr/bin/env python3
"""
fm26_dbchanges_gui2.py

Cross-platform (Windows/macOS/Linux) GUI for:
1) Extracting clubs/cities/nations from FM "db_changes" XML into master_library.csv
2) Generating batch + single FM26 editor XML youth players using generator2.

Friendly UI features:
- Output/Errors pane is hidden by default (Show/Hide button)
- File input paths are hidden by default (Show/Hide button)
- Live stdout/stderr streaming into the output box
- Auto-detects FM26 editor data folder and sets good defaults

No pip required:
- Built-in calendar picker for DOB fields (no tkcalendar dependency)
"""

from __future__ import annotations




from ui.name_paths import _preferred_name_csv_path
from ui.app_shell import AppShellMixin
from ui.state import StateVarsMixin

import os
import sys
import csv
import re
import threading
import subprocess
import calendar as _cal
import datetime as _dt
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from ui.date_picker import DatePickerPopup, DateInput
from ui.tooltips import _bind_help, _ToolTip, _attach_tooltip, _hoverhelp_autobind
from ui.runner import RunnerMixin
from ui.scroll import ScrollMixin
from ui.pickers import PickerWidgetsMixin
from ui.output_pane import OutputPaneMixin
from ui.file_dialogs import FileDialogsMixin
from ui.library_parsing_helpers import LibraryParsingHelpersMixin

from data.library_loader import LibraryLoaderMixin
# [SCROLL_MIXIN_V2]

from tabs.people.player.subtabs.international import InternationalSubtabMixin
from tabs.people.player.subtabs.contract import ContractSubtabMixin
from tabs.people.player.subtabs.contract_overrides import ContractOverridesMixin
from tabs.people.player.subtabs.details import DetailsSubtabMixin
from tabs.people.player.ui_batch_tab import BatchTabUIMixin
from tabs.people.player.ui_single_tab import SingleTabUIMixin
from tabs.people.player.ui_common import PlayerUiCommonMixin
from tabs.people.player.subtabs.intl_cli_export import InternationalCliExportMixin
from tabs.people.player.generator_run import GeneratorRunMixin
from tabs.people.player.generator_runner_common import GeneratorRunnerCommonMixin
from tabs.people.player.details_height_bridge import DetailsHeightBridgeMixin
# [INTL_CLI_EXPORT_MIXIN_V1]

from tabs.xml_appender.tab import XmlAppenderMixin
from tabs.xml_appender.actions import XmlAppenderActionsMixin

from tabs.extractor.tab import ExtractorTabMixin
# [EXTRACTOR_MOD_V1]

# [XML_APPENDER_MOD_V1]

from tabs.settings.tab import SettingsTabMixin
from ui.cli_utils import _quote

from ui.path_utils import ensure_parent_dir

from tabs.people.player.subtabs.contract_overrides_engine import ContractOverridesEngineMixin

from tabs.people.player.details_dontset import DetailsDontSetMixin

from tabs.people.player.ui_cleanup import AppCleanupMixin

from tabs.people.player.nonplayer_job_pickers import NonPlayerJobPickersMixin

from ui.job_roles import JobRolesMixin

from tabs.people.player.subtabs.details_utils import DetailsUtilsMixin

from ui.mode_binders import ModeBindersMixin

from ui.path_resolve import PathResolveMixin

from tabs.people.player.run_safe import RunSafeMixin

from ui.date_helpers import DateHelpersMixin

# [SETTINGS_MOD_V1]

# [DETAILS_MOD_V1]

# [CONTRACT_MOD_V3]

# [INTL_MIXIN_WIRING_V4]
APP_TITLE = "FM26 Generator"
GUI_BUILD = "v65.10-unified-nationfix-jobs-tabs-2026-02-26"
DEFAULT_EXTRACT_SCRIPT = "fm26_db_extractor.py"
DEFAULT_GENERATE_SCRIPT = "fm26_people_generator.py"
DEFAULT_XML_APPENDER_SCRIPT = "fm26_xml_appender.py"

# Positions list must match the generator's internal POS map.
ALL_POS = ["GK","DL","DC","DR","WBL","WBR","DM","ML","MC","MR","AML","AMC","AMR","ST"]
class App(InternationalSubtabMixin, ContractSubtabMixin, ContractOverridesMixin, DetailsSubtabMixin, SettingsTabMixin, XmlAppenderMixin, XmlAppenderActionsMixin, ExtractorTabMixin, RunnerMixin, GeneratorRunMixin, ScrollMixin, InternationalCliExportMixin, BatchTabUIMixin, SingleTabUIMixin, PickerWidgetsMixin, LibraryLoaderMixin, PlayerUiCommonMixin, LibraryParsingHelpersMixin, StateVarsMixin, AppShellMixin, DetailsHeightBridgeMixin, GeneratorRunnerCommonMixin, OutputPaneMixin, FileDialogsMixin, ContractOverridesEngineMixin, DetailsDontSetMixin, AppCleanupMixin, NonPlayerJobPickersMixin, JobRolesMixin, DetailsUtilsMixin, ModeBindersMixin, PathResolveMixin, RunSafeMixin, DateHelpersMixin, tk.Tk):
    def _autoclear_dontset(self, src_var, dont_set_var) -> None:
        """When src_var changes, clear dont_set_var.
        Prevents accidental --omit-field when user selected Random/Range."""
        try:
            src_var.trace_add("write", lambda *_: dont_set_var.set(False))
        except Exception:
            pass

    def __init__(self) -> None:
        super().__init__()
        # Keep title/build info available across extracted modules
        try:
            self._app_title = APP_TITLE
            self._gui_build = GUI_BUILD
        except Exception:
            pass
        # Install global combobox patches if present (safe no-op if missing)
        try:
            self._install_global_combobox_patches()
        except Exception:
            pass
        self._init_state_vars()
        self._build_shell()
        self._wire_tabs()
    def _get_fixed_ids(self, kind: str, label: str) -> tuple[str, str] | None:
        """Resolve a picker label to (dbid, large).

        Accepts either:
        - exact picker labels like 'Scotland (DBID 11)'
        - plain names like 'Scotland'
        - 'Nation DBID 11' / 'City DBID 123' fallbacks

        This is deliberately forgiving because some UI pickers store plain names.
        """
        if not label:
            return None

        label_s = str(label).strip()
        if not label_s:
            return None

        if kind == "club":
            mp = getattr(self, "_club_map", {}) or {}
        elif kind == "city":
            mp = getattr(self, "_city_map", {}) or {}
        elif kind == "nation":
            mp = getattr(self, "_nation_map", {}) or {}
        else:
            mp = {}

        # 1) exact match
        hit = mp.get(label_s)
        if hit:
            return hit

        # 2) match by DBID in label
        m = re.search(r"\bDBID\s*(\d+)\b", label_s, flags=re.I)
        if m:
            want = m.group(1)
            for k, v in mp.items():
                try:
                    if re.search(rf"\bDBID\s*{re.escape(want)}\b", str(k), flags=re.I):
                        return v
                except Exception:
                    continue

        # 3) plain-name match (case-insensitive) against the left side of ' (DBID …)'
        want_name = label_s.split("(")[0].strip().lower()
        if want_name:
            for k, v in mp.items():
                try:
                    kname = str(k).split("(")[0].strip().lower()
                except Exception:
                    continue
                if kname == want_name:
                    self._build_contract_tab_common(selft_path)

    # ---------------- Players (Batch) UI ----------------




